Trivia game with randomization on qoestions list, based on bank of questions and answers. 
the game include 15 questions, every good question give the user 10 points. 
in the end of the game, will print to user the total score he did. 