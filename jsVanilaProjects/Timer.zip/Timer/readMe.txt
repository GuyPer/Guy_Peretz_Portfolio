Timer of hours, minutes, seconds.
User could set the time he wants and start the timer by clicking on button "Start The Timer!", when time down to 0, the screen will paint on gold.
Anytime the user can stop the timer by using "Stop The Timer" button ,that will change by click to "Resume The Timer", so user can press on this button again to resume the timer. 
In addition, user can zero the timer anytime he wants by using the "Zero The Timer" button. 