Guess a number between 1-100, while you start with score of 100, every mistake you get clue for the number -
too high or too low.
while you mistake the screen will be red, when you right screen will be green and the score 
will print instead of the "?" field.
In addition, if the score is the best the Highscore will updated.