Tic Tac Toe game.
3 of "X" or "O" in a row will finish the game with a winner. 
There is an option to play again, by clicking on "play again" button.
This game is rensponsivy on Mobile/Tablet/Desktop.